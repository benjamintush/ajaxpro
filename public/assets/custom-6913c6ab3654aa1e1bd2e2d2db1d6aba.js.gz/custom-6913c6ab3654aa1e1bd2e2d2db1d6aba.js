jQuery(document).ready(function ($) {
//    $.getJSON("/urls.json", function(data) {
//        $("#items").html($("#item_template").tmpl(data));
//    });

//    $.validator.addMethod("url", function(value, element) {
//        return this.optional(element) || /^(http:\/\/www\.|https:\/\/www\.|http:\/\/|https:\/\/|www\.)[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/.*)?$/.test(value);
//    }, "Please enter a valid url address.");
//
//    // Validate urlform form
//    $("#url_form").validate({
//        rules: { url: "required url"}
//    });

//    $('#url_form').submit(function (e) {
//        if($(this).valid()){
//            var content = $('#url').val();
//            e.preventDefault();
//            $("#url_ul").prepend('<li> '+content+'</li>');
//            $(this).trigger('reset');
//        }
//        else {
//
//        }
//    });
});
